# Vexsoluciones Woocommerce Urbaner Assets #
https://www.pasarelasdepagos.com
Copyright (c) 2020 Vexsoluciones
Licensed under the GPLv2 license.

Assets such as styles, javascript, and images.