/* 
 * * Woocommerce Peru Ubigeos
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
/* Ubigeo Google Map */
var googleMap = {
    //apiKey: /*wp.googleApiKey*/ 'AIzaSyDVemmw6iajTRV7x_F2kwWdZEdash9HQ9Y',
    mapContainer: null,
    searchInput: null,
    latField: null,
    lgtField: null,
    enqueueGoogleScript: function(trigger) {
        if(typeof google === 'undefined') {
            let script = document.createElement('script');
            script.type = 'text/javascript';
            // var apikey =document.getElementById("apioculta").value;
            var apikey='AIzaSyAhA8t7SROb9On0BhkzTNrwOd5iq8QPKVA';
            script.src = 'https://maps.googleapis.com/maps/api/js?v=3&key='+apikey+'&sensor=false&libraries=places';
            script.onload = trigger;
            document.body.appendChild(script);
        } else 
            trigger();
    },
    initFromGeocoder: function(mapContainer, address) {
        var self = this;
        var geocoder = new google.maps.Geocoder();
        geocoder.geocode({'address': address}, function(results, status) {
            if(status === google.maps.GeocoderStatus.OK) {
                var latitude = results[0].geometry.location.lat();
                var longitude = results[0].geometry.location.lng();
                mapContainer.find('.geo_latitude').val(latitude);
                mapContainer.find('.geo_longitude').val(longitude);
                self.init(mapContainer);
                jQuery(document.body).trigger("update_checkout");
            } else
                googleMap.initFromGeocoder(mapContainer, 'Lima, Perú');
        });
    },
    initFromLatLgt: function(mapContainer, lat, lgt) {
        mapContainer.find(".geo_latitude").val(lat);
        mapContainer.find(".geo_longitude").val(lgt);
        init(mapContainer);
    },
    init: function(mapContainer) {
        this.mapContainer = mapContainer;
        this.searchInput = jQuery('#billing_address_1');
        this.latField = this.mapContainer.find(".geo_latitude");
        this.lgtField = this.mapContainer.find(".geo_longitude");
        this.initializeMap();
        /* fix for modals that the autocomplete is no visible */
        var pacContainerInitialized = false;
        this.searchInput.keypress(function() {
            if(!pacContainerInitialized) {
                jQuery('.pac-container').css('z-index', '99999999999');
                pacContainerInitialized = true;
            }
        });
    },
    initializeMap: function() {
        var self = this;
        var maps = [];
        var mapCanvas = this.mapContainer.find( '.olva-location-field-map' );
        var latLng = new google.maps.LatLng( this.latField.val(), this.lgtField.val() );
        var zoom = 14;
        // Create map instance
        var mapOptions = {
            center: latLng,
            zoom: zoom
        };
        var map = new google.maps.Map( mapCanvas[0], mapOptions );
        /* on change lat lgt */
        this.latField.on('change', function() {
            map.setCenter( new google.maps.LatLng( this.latField.val(), this.lgtField.val() ) );
        });

        this.lgtField.on('change', function() {
            map.setCenter( new google.maps.LatLng( this.latField.val(), this.lgtField.val() ) );
        });
        // Marker
        var markerOptions = {
            map: map,
            draggable: true,
            title: 'Arrastre para establecer la posición exacta'
        };
        var marker = new google.maps.Marker( markerOptions );
        if(this.latField.val().length > 0 && this.lgtField.val().length > 0) 
            marker.setPosition( latLng );
        // Allow marker to be repositioned
        google.maps.event.addListener( marker, 'drag', function() {
            self.latField.val(marker.getPosition().lat());
            self.lgtField.val(marker.getPosition().lng());
        });
        // Search
        if(this.searchInput.length > 0) {
            var autocomplete = new google.maps.places.Autocomplete( this.searchInput[0] );
            autocomplete.bindTo('bounds', map);
            this.searchInput.keypress( function( event ) {
                if(event.keyCode === 13) {
                    event.preventDefault();
                    self.initFromGeocoder(self.mapContainer, self.searchInput.val());
                }
            });
            google.maps.event.addListener(autocomplete, 'place_changed', function() {
                var place = autocomplete.getPlace();
                if(!place.geometry) 
                    return;
                if(place.geometry.viewport)
                    map.fitBounds(place.geometry.viewport);
                else {
                    map.setCenter(place.geometry.location);
                    map.setZoom( 17 );
                }
                marker.setPosition( place.geometry.location );
                self.latField.val( place.geometry.location.lat() );
                self.lgtField.val( place.geometry.location.lng() );
            });
        }
        maps.push(map);
        this.mapContainer.show();
    }
};