<?php
/*body 1
{"orderId":"17","status":"error","attachment":{"errors":{"address_to":{"reference":["length must be within 0 - 25"]},"consignment_note_class_code":["código de clase de producto para carta porte inválido"]}}}
body2
{
  "orderId": "213123",
  "status": "error",
  "attachment": {
    "message": "Créditos insuficientes para realizar la guía.",
    "code": "insufficient_funds"
  }
}
body3
{
   "orderId":"1234",
   "status":"fullfillmert",
   "attachment":{
      "labelURL":"https://someurl.com/34213.pdf"
      "tracking_number":"5050"
   }
}
*/
require('../../../../wp-load.php');
global $wpdb;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

     $raw_data = file_get_contents('php://input');
   $datos = json_decode($raw_data, true);
   if($datos)
   {
       echo "Datos almacenados con exito";
   }
   else{
       echo "Ha ocurrido un error";
       exit();
   }
    //var_dump($datos);
    $data = $datos['attachment'];

  
    update_post_meta($datos["orderId"], "skydropx_id", $datos["orderId"]);
    update_post_meta($datos["orderId"], "skydropx_status", $datos["status"]);
    if($datos["status"]=="error")
    {
 
        $referencia=$data['errors']['address_to']['reference'];
        $nota=$data['errors']['consignment_note_class_code'];
        $nota2=$nota[0];
        $referencia2=$referencia[0];
    //var_dump($referencia2);
        update_post_meta($datos["orderId"], "skydropx_nota", $nota2);
        update_post_meta($datos["orderId"], "skydropx_referencia", $referencia2);
        update_post_meta($datos["orderId"], "skydropx_error", $data['message']);
        update_post_meta($datos["orderId"], "skydropx_error_code", $data['code']);
    }
    else
    {
    update_post_meta($datos["orderId"], "skydropx_trackingurl", $data['label_url']);
    update_post_meta($datos["orderId"], "skydropx_trackingprovider", $data['tracking_url_provider']);
    update_post_meta($datos["orderId"], "skydropx_tracking", $data['tracking_number']);
    }

    if (is_array($data)) {
        $fh = fopen("log_data.txt", "a+");

        if ($fh) {
            fwrite($fh, date('Y-m-d H:i:s', time()).PHP_EOL);
            fclose($fh);
        } else {
            print("Sorry, Unable to open file!");
        }
    } else {
        print("sorry, Invalid data!");
    }
} 
else {
  print("sorry, Invalid request!");
    $_POST[''];
}