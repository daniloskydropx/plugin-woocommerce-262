# Vexsoluciones Woocommerce Urbaner Includes #
https://www.pasarelasdepagos.com
Copyright (c) 2020 Vexsoluciones
Licensed under the GPLv2 license.

Additional PHP functionality goes here.