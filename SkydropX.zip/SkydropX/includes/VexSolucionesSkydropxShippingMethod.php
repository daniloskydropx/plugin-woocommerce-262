<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined( 'ABSPATH' ) || exit;

class VexSolucionesSkydropxShippingMethod extends WC_Shipping_Method {

    const ID = "vex_soluciones_skydropx";
    const AVAILABLE_COUNTRIES = ["MX"];
    const MAX_WEIGHT = 30;
    const SHIPPING_STATE = "skydropx_shipping_state";
    const SHIPPING_SKYDROPX_TYPE = 'shipping_skydropx_type';

    public function __construct() {
        $lic=get_option('skydropx_licensia');
        if(empty($lic))
        {
            $notify='<br>Active el plugins accediendo a este <a href="'.get_site_url().'/wp-admin/admin.php?page=skydropx_license">enlace</a>';
        }
        else
        {
            $notify="";
        }
       
        $this->id = self::ID; 
        $this->method_title = __( 'Método de Envío Skydropx', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN );  
        $this->method_description = __( 'El plugin de <a href="#"> Skydropx </a> para Woocommerce te permite conectar tu tienda online e-commerce con tu proveedor de Logística <a href="#"> Skydropx </a> en mínutos.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); 
        $this->availability = 'including';
        $this->title = __( 'Método de Envío Skydropx', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN );
        $this->countries = self::AVAILABLE_COUNTRIES;
        $this->enabled = "yes";
        $this->init();
    }

    function init() {
        // Load the settings API
        $this->init_form_fields(); 
        $this->init_settings(); 
        // Save settings in admin if you have any defined
        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
    }
    
    public function generate_settings_html($form_fields=[], $echo=true) {
        ob_start();
        Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->renderSettingsPage();
        return ob_get_clean();
    }
    
    public function process_admin_options() {
        try {
            Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->save();
            return true;
        } catch(Exception $e) {
            Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->renderNotice(__("Error:", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), $e->getMessage(), "error");
        }
        return false;
    }
    
    public function calculate_shipping($package=[]) {
        /* rates */
        $rate = array(
            'id'    => self::ID,   // ID for the rate
            'label' => __("Skydropx", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            'cost'  => self::getCostSkydropx($package),
            // "calc_tax" => "per_order", // per_item
            // "taxes" => false // []
        );
        $this->add_rate($rate);
    }
    
    public static function doIfShippingIsSkydropx($callback) {
        $country = WC()->customer->get_shipping_country();
        foreach(WC()->session->get( 'chosen_shipping_methods' ) as $index => $selectedShippingMethod) {
            if(in_array($country, VexSolucionesSkydropxShippingMethod::AVAILABLE_COUNTRIES) && $selectedShippingMethod === self::ID) 
                $callback(WC()->cart->get_shipping_packages()[$index]);
        }
    }
    
    public static function getCostSkydropx($package, $shippingType=false, $precio=false, $count=false) {
        $settings = self::getSettingsForPackage($package);
      $cost=0;
       
        for ($i = 0; $i < $count; ++$i)
        {
            if($shippingType==$i):
                $cost=$precio;
            endif;
        }
        $cost= apply_filters('skydropx_shipping_cost', $cost);
  
            
return $cost;
}
    
    /**
     * @return  VexSolucionesSkydropxSettings
     */
    public static function getSettingsForOrder($order) {
        $item = array_shift($order->get_items());
        $productItem = new WC_Order_Item_Product($item);
        $productPost = get_post($productItem->get_product()->get_id());
        $vendorId = $productPost->post_author;
        return Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings($vendorId);
    }
    
    // get the first product author within array of products in the package
    public static function getProductAuthorForPackage($package) {
        $oneItem = array_shift($package['contents']);
        $post = get_post($oneItem['product_id']);
        $vendorId = $post->post_author;
        return $vendorId;
    }
    
    /*
     * @return VexSolucionesSkydropxSettings
     */
    public static function getSettingsForPackage($package) {
        $author = self::getProductAuthorForPackage($package);
        return Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings(user_can($author, 'administrator') ? false : $author);
    }

}

/* Disabled ajax checkout, for testing....
 * function disable_checkout_script(){
    wp_dequeue_script( 'wc-checkout' );
}
add_action( 'wp_enqueue_scripts', 'disable_checkout_script' ); */
