<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined( 'ABSPATH' ) || exit;

class VexSolucionesUtils {
    
    public static function getDaysTranslated($vacaKeys=0, $numChars=0) {
        $days = [
            "monday" => __("Lunes", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "tuesday" => __("Martes", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "wednesday" => __("Miercoles", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "thursday" => __("Jueves", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "friday" => __("Viernes", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "saturday" => __("Sabado", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "sunday" => __("Domingo", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN)
        ];
        if($vacaKeys === 1) {
            $days2 = [];
            foreach($days as $day)
                $days2[] = $day;
            $days = $days2;
        } else if($vacaKeys === -1) {
            $days2 = [];
            foreach($days as $key => $day)
                $days2[] = $key;
            $days = $days2;
        }
        if($numChars != 0) {
            foreach($days as &$day)
                $day = substr($day, 0, intval($numChars));
        }
        return $days;
    }
    
    public static function getMonthsTraslated($vacaKeys=0, $numChars=0) {
        $months = [
            "january" => __("Enero", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "february" => __("Febrero", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "march" => __("Marzo", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "april" => __("Abril", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "may" => __("Mayo", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "june" => __("Junio", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "july" => __("Julio", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "august" => __("Agosto", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "september" => __("Septiembre", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "october" => __("Octubre", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "november" => __("Noviembre", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            "december" => __("Diciembre", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
        ];
        if($vacaKeys === 1) {
            $months2 = [];
            foreach($months as $month)
                $months2[] = $month;
            $months = $months2;
        } else if($vacaKeys === -1) {
            $months2 = [];
            foreach($months as $key => $month)
                $months2[] = $key;
            $months = $months2;
        }
        if($numChars != 0) {
            foreach($months as &$month)
                $month = substr($month, 0, intval($numChars));
        }
        return $months;
    }
    
    public static function getFromJsonFile($path) {
        $json = file_get_contents($path);
        if($json) {
            $arr = json_decode($json, true);
            if($arr)
                return $arr;
        }
        return false;
    }
    
    public static function getDistanceFromLatLonInKm($lat1, $lon1, $lat2, $lon2) {
        $R = 6371; // Radius of the earth in km
        $dLat = deg2rad($lat2-$lat1);
        $dLon = deg2rad($lon2-$lon1); 
        $a = 
          sin($dLat/2) * sin($dLat/2) +
          cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * 
          sin($dLon/2) * sin($dLon/2)
        ; 
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        $d = $R * $c; // Distance in km
        return $d;
    }
    
}
