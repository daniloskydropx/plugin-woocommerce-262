<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

/**
 * Description of VexsolucionesSkydropxCheckout
 *
 * @author jedi
 */
class VexsolucionesSkydropxCheckout {
    
    public function addSkydropxToShippingMethods($methods) {
        $methods[] = 'VexSolucionesSkydropxShippingMethod';
        return $methods;
    }
    
    public function process() {}
    
    public function updateOrderMeta($orderid) {
        $order = wc_get_order($orderid);
        $posts = get_children([
            'post_type' => 'shop_order',
            'posts_per_page' => -1,
            'post_parent' => $orderid,
            'order' => 'ASC'
        ]);
        
        $index = 0;
        foreach($posts as $childOrder) {
            $subOrder = wc_get_order($childOrder->ID);
            Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($subOrder, function() use($subOrder, $index) {
                $settings = VexSolucionesSkydropxShippingMethod::getSettingsForOrder($subOrder);
                $this->superVacacheckoutUpdateOrderMeta($subOrder->get_id(), $settings, $index);
               // self::courierAvailability($subOrder->get_id(), $settings);
            });
            $index++;
        }
        // send skydropx shipping if no suborders exists
        if(!count($posts)) {
            Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($order) {
                $settings = VexSolucionesSkydropxShippingMethod::getSettingsForOrder($order);
                $this->superVacacheckoutUpdateOrderMeta($order->get_id(), $settings);
              // self::courierAvailability($order, $settings);
            });
        }

        Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($order) {
          if($order->get_shipping_total() == 0) {
              wc_add_notice(__("Ha ocurrido un error verifique sus datos e intente nuevamente"), "error");
              throw new Exception();
          }
      });
    }


    private function superVacacheckoutUpdateOrderMeta($orderid, $settings, $index=0) {
        if(!array_key_exists(VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE. '_' . $index, $_POST)) {
            wc_add_notice(__("Debes seleccionar un tipo de envío."), "error");
            throw new Exception();
        }
        $precio = WC()->session->get('cart_totals')['shipping_total'];
        if($precio=0)
        {
          wc_add_notice(__("Ha ocurrido un error intente nuevamente."), "error");
            throw new Exception();
        }
      
        $shippingType = filter_var($_POST[VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE. '_' . $index], FILTER_VALIDATE_INT);
        $prueba=$_POST['nameenvio'.$shippingType.'_'.$index];
        $service=$_POST['level_code'.$shippingType.'_'.$index];
        $provider=$_POST['provider'.$shippingType.'_'.$index];

        switch($shippingType) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:    
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
                update_post_meta($orderid, VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE, $shippingType);
                update_post_meta($orderid, 'skydropx_paqueteria', $prueba);
                update_post_meta($orderid, 'skydropx_provider', $provider);
                update_post_meta($orderid, 'skydropx_servicio', $service);
                break;
            default:
                wc_add_notice(__("Tipo de envío inválido ({$shippingType})."), "error");
                throw new Exception();
        }

        $shipToDifferentAddress = isset($_POST["ship-to-different-address-checkbox"]) ? "1" : "0";
        update_post_meta($orderid, "skydropx_different_shipping_address", $shipToDifferentAddress);
        if($settings->getWoocommerceDefaultStatus()=="wc-completed")
        {
            $status="Completada";
        }
        if($settings->getWoocommerceDefaultStatus()=="wc-pending")
        {
            $status="Pendiente de pago";
        }
        if($settings->getWoocommerceDefaultStatus()=="wc-processing")
        {
            $status="Procesando";
        }
        if($settings->getWoocommerceDefaultStatus()=="wc-on-hold")
        {
            $status="En espera";
        }
        update_post_meta($orderid, VexSolucionesSkydropxShippingMethod::SHIPPING_STATE, "La orden debe entrar en estado '{$status}' para que el pedido sea enviado a skydropx", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);

    }

    
     public static function sendSkydropxShipping($order, $settings) {
     //   $shippingType = intval(get_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE, true));
        $wharehouse = VexSolucionesWharehouse::getClosestWharehouse($settings->getWharehouses(), 44444, 77777);

        $dateTime = get_post_meta($order->get_id(), "skydropx_shipping_datetime", true);
        $dateTime = str_replace('/', '-', $dateTime);
        $BillingShipping = $order->has_shipping_address() ? 'billing' : 'shipping';
        $nota = "";
        $nota .= __(' nota: Los almacenes de la tienda laboran los siguientes dias en los horarios: ', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
        $settings->getTimesShedules()->appendAllSchedulesToString($nota);
        $nota = str_replace('<br>', '', $nota);
        $nota = str_replace('/n referencia:', '', $nota);
        $nota .= ' ' . $order->get_customer_note();
        $productoslistado = 'Productos: ';
        $items = '';
        $weightCumul = 0;
                 $totalheight=0;
             $totalwidth=0;
             $totallength=0;
        foreach ( $order->get_items() as $item_id => $item ) {
            $product = $item->get_product();
            $weightCumul += empty($product->weight) ? 0 : $product->weight;
           
            $qty = $item->get_quantity();


        // Get product dimensions  
        $length = $product->get_length();
        $width  = $product->get_width();
        $height = $product->get_height();
       $weight = $product->get_weight();
       if($height>$totalheight):
        $totalheight=$height;
    endif;
    if($width>$totalwidth):
        $totalwidth=$width;
    endif;
    if($length>$totallength):
        $totallength=$length;
    endif;
        // Calculations a item level
        $totalweight1=$weight*$qty;
        $totalweight+=$totalweight1;
  }
  $address2=$order->get_shipping_address_2();
  $company=$order->get_billing_company();
  if(empty($address2)):
    $address2="colonia";
  endif;
  if(empty($company)):
    $company="-";
  endif;



        $keyconfig = $settings->getSkydropxApiKey();
$curl = curl_init();
 $url = $settings->getEnvironmentMode() === 'enabled' ? 'https://sb-ecommerce-service.skydropx.com' : 'https://ecommerce-service.skydropx.com';
        $urlCurl = "{$url}/v1/order/";
        //a modo de vaidar los datos en envio manual
          $campos='{
            "number": "'.$order->get_id().'",
            "shop_id": "'.get_option('skydropx_shopid').'",
            "consignment_note_class_code":"24112900",
            "consignment_note_packaging_code":"1H1",
            "shipment": {
              "rates": {
                "provider": "'.get_post_meta($order->get_id(), "skydropx_provider", true).'",
                "service_level_code": "'.get_post_meta($order->get_id(), "skydropx_servicio", true).'"
              }
            },
      "address_from": {
      "province": "'.$wharehouse->province.'",
      "city": "'.$wharehouse->district.'",
      "name": "'.$wharehouse->contactName.'",
      "zip": "'.$wharehouse->zip.'",
      "country": "MX",
      "address1": "'.$wharehouse->dir1.'",
      "company": "'.$wharehouse->company.'",
      "address2": "'.$wharehouse->dir2.'",
      "phone": "'.$wharehouse->contactPhone.'",
      "email": "'.$wharehouse->email.'"
      },
      "parcels": [{
        "weight": '.$totalweight.',
        "distance_unit": "CM",
        "mass_unit": "KG",
        "height": '.$totalheight.',
        "width": '.$totalwidth.',
        "length": '.$totallength.'
      }],
      "address_to": {
        "province": "'.$order->get_shipping_state().'",
        "city": "'.$order->get_shipping_city().'",
        "name": "'.$order->get_shipping_first_name().' '.$order->get_shipping_last_name().'",
        "zip": "'.$order->get_shipping_postcode().'",
        "country": "MX",
        "address1": "'.$order->get_shipping_address_1().'",
        "company": "'.$company.'",
        "address2": "'.$address2.'",
        "phone": "'.$order->get_billing_phone().'",
        "email": "'.$order->get_billing_email().'",
        "contents": "paquete"
      }
    }';
curl_setopt_array($curl, array(
  CURLOPT_URL => $urlCurl,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
 // CURLOPT_POSTFIELDS => '$campos',
    CURLOPT_POSTFIELDS => '{
      "number": "'.$order->get_id().'",
      "shop_id": "'.get_option('skydropx_shopid').'",
      "consignment_note_class_code":"24112900",
      "consignment_note_packaging_code":"1H1",
      "shipment": {
        "rates": {
          "provider": "'.get_post_meta($order->get_id(), "skydropx_provider", true).'",
          "service_level_code": "'.get_post_meta($order->get_id(), "skydropx_servicio", true).'"
        }
      },
"address_from": {
"province": "'.$wharehouse->province.'",
"city": "'.$wharehouse->district.'",
"name": "'.$wharehouse->contactName.'",
"zip": "'.$wharehouse->zip.'",
"country": "MX",
"address1": "'.$wharehouse->dir1.'",
"company": "'.$wharehouse->company.'",
"address2": "'.$wharehouse->dir2.'",
"phone": "'.$wharehouse->contactPhone.'",
"email": "'.$wharehouse->email.'"
},
"parcels": [{
  "weight": '.$totalweight.',
  "distance_unit": "CM",
  "mass_unit": "KG",
  "height": '.$totalheight.',
  "width": '.$totalwidth.',
  "length": '.$totallength.'
}],
"address_to": {
  "province": "'.$order->get_shipping_state().'",
  "city": "'.$order->get_shipping_city().'",
  "name": "'.$order->get_shipping_first_name().' '.$order->get_shipping_last_name().'",
  "zip": "'.$order->get_shipping_postcode().'",
  "country": "MX",
  "address1": "'.$order->get_shipping_address_1().'",
  "company": "'.$company.'",
  "address2": "'.$address2.'",
  "phone": "'.$order->get_billing_phone().'",
  "email": "'.$order->get_billing_email().'",
  "contents": "paquete"
}
}',

  CURLOPT_HTTPHEADER => array(
    "authorization: token=".$keyconfig."",
    "cache-control: no-cache",
    "content-type: application/json",
  ),
));

$response = curl_exec($curl);
$array = json_decode($response, true);

$err = curl_error($curl);
//var_dump($campos);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
if($httpCode !== 200)
 {
  $dataa = $array['errors'];
  foreach($dataa as $code)
        {
        $errordetail=$code['detail'];
        }

            update_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE, 'Ocurrió un error al comunicarse con skydropx: '.$code['status'].'-'.$errordetail);
            //wc_add_notice( 'Ha ocurrido un error: '.$errordetail.'', 'error' );
            echo '<div class="notice notice-error is-dismissible>Ha ocurrido un error: '.$errordetail.'</div>';
        
} 
else {
            update_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE,'Solicitud enviada con éxito');
          
        }
       
        curl_close($curl);

}


    public function fixAjaxUpdateOrderReviewCost() {
      /* fix rates for ajax */
      $data = [];
      if(array_key_exists("post_data", $_POST))
          parse_str($_POST["post_data"], $data);
      foreach(WC()->cart->get_shipping_packages() as $index => $productsPackages) {
          $shippingType = $data[VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE . "_{$index}"];
          $ratesPackages = WC()->session->get("shipping_for_package_{$index}");
          $precio=$data["precio_".$shippingType."_".$index];
          $long=$data["countpa"];
          $shipping_taxes = WC_Tax::calc_shipping_tax(VexSolucionesSkydropxShippingMethod::getCostSkydropx($productsPackages, $shippingType, $precio, $long), WC_Tax::get_shipping_tax_rates());
          $rate = new WC_Shipping_Rate(VexSolucionesSkydropxShippingMethod::ID, __("Skydropx", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), VexSolucionesSkydropxShippingMethod::getCostSkydropx($productsPackages, $shippingType, $precio, $long),$shipping_taxes, 'vex_soluciones_skydropx');
          $ratesPackages["rates"]["vex_soluciones_skydropx"] = $rate;
          WC()->session->set("shipping_for_package_{$index}", $ratesPackages);
      }
  }
    
   public function transitionStatus($newStatus, $oldStatus, $post) {
        $status = $newStatus;
        if($newStatus == $oldStatus)
            $status = $_POST['order_status'];
        $order = wc_get_order($post->ID);
        Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($status, $order) {
            $settings = VexSolucionesSkydropxShippingMethod::getSettingsForOrder($order);
            if($status == $settings->getWoocommerceDefaultStatus()) {
                $deliveryTrack = get_post_meta($order->get_id(), "skydropx_id", true);
                if(empty($deliveryTrack)) 
                    self::sendSkydropxShipping($order, $settings);
            }   
        });
    }
    

}