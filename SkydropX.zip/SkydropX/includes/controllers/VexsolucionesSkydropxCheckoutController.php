<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexsolucionesSkydropxCheckoutController {
    
    private static $instance = null;
    private static $updateOrderReviewAlreadyRender = false;
    
    public static function getInstance() {
        if(self::$instance === null)
            self::$instance = new VexsolucionesSkydropxCheckoutController;
        return self::$instance;
    }
    
    private $skydropxCheckout, $skydropxOrderDetails;
    
    function __construct() {
        $this->skydropxCheckout = new VexsolucionesSkydropxCheckout;
        $this->skydropxOrderDetails = new VexSolucionesOrderTrackingLink;
    }
    
    public function reviewOrderFieldsAction() {
        $shippingDateTimePicker = new VexSolucionesShippingDateTimePicker;
        if(!self::$updateOrderReviewAlreadyRender) {
            add_action('woocommerce_after_shipping_rate', function($method, $index) use($shippingDateTimePicker) {
                if($method->get_id() == VexSolucionesSkydropxShippingMethod::ID)
                    $shippingDateTimePicker->render($index, $method, WC()->cart->get_shipping_packages()[$index]);
            }, 10, 2); 
            self::$updateOrderReviewAlreadyRender = true;
        }
        add_action("wp_enqueue_scripts", [$shippingDateTimePicker, 'enqueueScripts']);
    }
    
    public function processAction() {
        add_action("woocommerce_checkout_process", [$this->skydropxCheckout, 'process']);
    }
    
    public function updateOrderMetaAction() {
        add_action("woocommerce_checkout_update_order_meta", [$this->skydropxCheckout, 'updateOrderMeta'], PHP_INT_MAX, 1);
    }
    
    public function addSkydropxToShippingMethodsAction() {
        add_filter( 'woocommerce_shipping_methods', [$this->skydropxCheckout, 'addSkydropxToShippingMethods']);
    }
    
    public function updateOrderReviewAction() {
        add_action("woocommerce_checkout_update_order_review", [$this->skydropxCheckout, 'fixAjaxUpdateOrderReviewCost']);
    }
    
    public function addMetaboxToOrderAction() {
        $skydropxMetabox = new VexsolucionesSkydropxMetabox;
        add_action("add_meta_boxes", [$skydropxMetabox, 'addToOrderDetails'], 10, 2);
    }
    
    public function addSkydropxDetailsAction() {
        add_filter( 'woocommerce_my_account_my_orders_actions', [$this->skydropxOrderDetails, 'myAccountOrderTrackingLink'], 10, 2 );
        add_action("woocommerce_order_details_after_order_table", [$this->skydropxOrderDetails, 'orderDetailsTableTrackingButton'], 10, 1);
    }
    
    public function transitionOrderStatusAction() {
        add_action("transition_post_status", [$this->skydropxCheckout, 'transitionStatus'], PHP_INT_MAX, 3);
    }
    
}
