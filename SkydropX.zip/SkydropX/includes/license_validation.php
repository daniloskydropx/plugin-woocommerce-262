<?php
require('../../../../wp-load.php');
global $wpdb;
$curl = curl_init();
$licencia=$_POST['license'];
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://pasarelasdepagos.com?slm_action=slm_check&secret_key=587423b988e403.69821411&license_key'.$licencia.'',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Cookie: AWSALB=+bwFOIBUQoqEBgsb5hhQQhdUkTB/ZEQXxJAQGEO5XI1YujAplt1S9gaXTYZkmNlo0aitbEcQRZPSHlAcI+myjgQwqj4ElcwBNrgrpc/DdTAshnbkTbFbLP0OCFOf; AWSALBCORS=+bwFOIBUQoqEBgsb5hhQQhdUkTB/ZEQXxJAQGEO5XI1YujAplt1S9gaXTYZkmNlo0aitbEcQRZPSHlAcI+myjgQwqj4ElcwBNrgrpc/DdTAshnbkTbFbLP0OCFOf'
  ),
));

$response = curl_exec($curl);

curl_close($curl);
//echo $response;
$response=json_decode($response,true);
if($response['result']=='success')
{
  update_option('skydropx_licensia',$licencia);
  echo '<script>swal("Buen trabajo!", "Licencia validada con éxito!", "success"); 
  window.location.href = "admin.php?page=wc-settings&tab=shipping&section=vex_soluciones_skydropx";
  </script>';
  
}
else{
  delete_option( 'skydropx_licensia' );
  echo '<script>swal("Ha ocurrido un error!", "'.$response['message'].'", "error"); </script>';
}



