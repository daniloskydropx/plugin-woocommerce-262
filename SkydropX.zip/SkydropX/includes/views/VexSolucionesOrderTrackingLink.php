<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */


class VexSolucionesOrderTrackingLink {
    
    private static $alreadyTrackingButtonAdded = false;

    public function myAccountOrderTrackingLink($actions, $order) {
        Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($order, &$actions) {
            $skydropx_delivery_track = get_post_meta($order->get_id(), "skydropx_trackingurl", true);
            if(!empty($skydropx_delivery_track)):
                $actionId = 'skydropx_tracking_' . $order->get_id();
                $actions[$actionId] = [
                    'url'  => "#",
                    'name' => __("Ir a Tracking", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
                ]; ?>
                <script type="text/javascript">
                    jQuery(document).ready(function($) {
                       $('.<?php echo $actionId; ?>').off().on('click', function() {
                           window.open('<?= $skydropx_delivery_track ?>', '', 'width=640,height=480');
                       });
                    });
                </script>
                <?php
            endif;
        });
        return $actions;
    }
    
    public function orderDetailsTableTrackingButton($order) {
        $skydropx_delivery_track = get_post_meta($order->get_id(), "skydropx_trackingurl", true);
        if(!empty($skydropx_delivery_track) && !self::$alreadyTrackingButtonAdded): ?>
            <a style="float: right; position: relative; top: -68px;" class="button" href="#" onclick="window.open('<?= $skydropx_delivery_track ?>', '', 'width=640,height=480')"><?php echo __("Ir a Tracking", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></a>
            <?php
            self::$alreadyTrackingButtonAdded = true;
        endif;
    }
    
}
