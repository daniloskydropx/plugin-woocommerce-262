<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2021 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined('ABSPATH') || exit; 

if($method->id != VexSolucionesSkydropxShippingMethod::ID)
    return;
$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
$chosen_shipping = $chosen_methods[$index]; 
if($chosen_shipping != VexSolucionesSkydropxShippingMethod::ID)
    return;
    $chosen_shipping_method_price = WC()->session->get('cart_totals')['shipping_total'];
   
$package = WC()->cart->get_shipping_packages()[$index];
$check = array_key_exists(VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE . "_{$index}", $data) ? $data[VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE . "_{$index}"] : 100; 
if($chosen_shipping_method_price==0){
    ?>
        <style>iframe{display:none;}</style>
        <?php
}
?>


</td></tr> <!-- Fix Woocommerce -->

<tr class="woocommerce-shipping-totals shipping skydropxvex">
    <th>
        <h5 style="color: #737373; display: inline; font-size: 14px; font-weight: bold;"><?php echo __("Opciones de envío", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h5>
    </th>
    <td>
        <p style="padding-left: 15px;">
        <?php 
//obtener paqueteria
$data = [];
        if(array_key_exists("post_data", $_POST))
            parse_str($_POST["post_data"], $data);
            $zip=$data['billing_postcode'];

     if(!empty($zip)) {
            $wharehouse = VexSolucionesWharehouse::getClosestWharehouse($settings->getWharehouses(), $lat, $lgt);
            // $distance = VexSolucionesUtils::getDistanceFromLatLonInKm($wharehouse->lat, $wharehouse->lgt, $lat, $lgt);
            //$shippingType = intval($shippingType);
     
           // $returnToOrigin = $settings->returnToOrigin() == 'yes' ? 'true' : 'false';
             global $woocommerce;
             $heightmayor=0;
             $widthmayor=0;
             $lengthmayor=0;
                foreach(WC()->cart->get_cart() as $cart_item) { 
        // Get an instance of the WC_Product object and cart quantity
        $product = $cart_item['data'];
        $qty= $cart_item['quantity'];
        
        // Get product dimensions  
        $length = $product->get_length();
        $width  = $product->get_width();
        $height = $product->get_height();
        $weight = $product->get_weight();
        if (empty($length) && empty($width) && empty($height) && empty($weight)) {
            wc_add_notice( 'Algunos de los productos en el carrito carecen de información requerida: verifique las dimensiones del producto', 'error' );
            return;
        }
if($height>$heightmayor):
    $heightmayor=$height;
endif;
if($width>$widthmayor):
    $widthmayor=$width;
endif;
if($length>$lengthmayor):
    $lengthmayor=$length;
endif;
        // Calculations a item level
 
       $totalweight1=$weight*$qty;
       $totalweight+=$totalweight1;
           }
           


$key=$settings->getSkydropxApiKey();
$url = $settings->getEnvironmentMode() === 'enabled' ? 'https://sb-ecommerce-service.skydropx.com' : 'https://ecommerce-service.skydropx.com';
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => "{$url}/v1/rates",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 30,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => "{\r\n  \"zip_from\": \"{$wharehouse->zip}\",\r\n  \"zip_to\": \"{$zip}\",\r\n  \"parcel\": {\r\n    \"weight\":{$totalweight},\r\n    \"height\": {$heightmayor},\r\n    \"width\": {$widthmayor},\r\n    \"length\": {$lengthmayor}\r\n  }\r\n}",
CURLOPT_HTTPHEADER => array(
    "authorization: token=".$key."",
    "Content-Type: application/json",
    "Accept: application/json"
),
));

$response = curl_exec($curl);
$httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
    $response = json_decode($response, true);
   
 
        if($httpcode===200)
        {
        $dato=$response['data'];
        //sucede que skydropx en varias  oprotunidades, cuando el peso es muy alto no devuelve datos de paqueteria
        if(empty($dato))
        {
            wc_add_notice( 'Sin respuesta de Skydropx, porfavor verifique dimensiones de los artículos', 'error' );
            return;
        }
       $long=count($dato);
       ?>
         <input name="countpa" type="hidden" value="<?php echo $long;?>">
   
       <?php
    
        for ($i = 0; $i < $long; ++$i){
    
      //echo $response[$i]['provider'].' ('.$response[$i]['service_level_name'].'):'.$response[$i]['total_pricing'].' '.$response[$i]['service_level_code'].'<br>';
      $precio=$dato[$i]['total_pricing'];
      $sameDayCost = VexSolucionesSkydropxShippingMethod::getCostSkydropx($package, $i, $precio, $long);
      if($sameDayCost != 0): ?>
      
    <label id="tipoenvio" style="display: block; padding: 5px 0; font-weight: bold;">

                <input class="typeshipping skydropx_<?php echo $i; ?>" type="radio" name="<?php echo VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE; ?>_<?php echo $index; ?>" id="skydropx_regular_<?php echo $index; ?>" value="<?php echo $i;?>" style="margin-right: 3px;" <?php if($chosen_shipping_method_price!=0 && $check==$i){echo "checked";}else{echo "";}?>>
                <?php
                setlocale(LC_TIME, "spanish");
                $fecha_actual = date("d-m-Y");
$fechaskydropx= date("d-m-Y",strtotime($fecha_actual."+ ".$dato[$i]['days']." days")); 
$fechaformat=date('l, d M',strtotime($fechaskydropx));
                echo $dato[$i]['provider']." <span style='font-size: 11px; font-weight: normal;'>({$dato[$i]['service_level_name']} - Llega el <span class='entrega'>".utf8_encode(strftime("%A, %d de %B",strtotime($fechaskydropx)))."</span>)</span><br>";
                echo get_woocommerce_currency_symbol().$sameDayCost; ?>
            </label>
            <input type="hidden" name="nameenvio<?php echo $i;?>_<?php echo $index;?>" value="<?php echo $dato[$i]['provider'].' ('.$dato[$i]['service_level_name'].')'?>">
            <input type="hidden" name="provider<?php echo $i;?>_<?php echo $index;?>" value="<?php echo $dato[$i]['provider']?>">
            <input type="hidden" name="level_code<?php echo $i;?>_<?php echo $index;?>" value="<?php echo $dato[$i]['service_level_code']?>">
            <input type="hidden" name="precio_<?php echo $i;?>_<?php echo $index;?>" value="<?php echo $precio;?>">
        
        <?php
        endif;
        }
        echo "<b>Disclaimer:</b> La fecha de entrega estimada varía de acuerdo al horario y día de entrega del paquete en la sucursal.";
    }
    else
    {
        $dataa = $response['errors'];
        foreach($dataa as $errores)
        {
        $errordetail=$errores['detail'];
        }
        wc_add_notice("Ha ocurrido un error: ".$errordetail." (verificar parámetros)", "error");
        return;
    }
    }
   /* else
    {
        header("refresh: 0");
    }*/

               ?>
             
        </p>
        <script type="text/javascript">
           /* jQuery(document).ready(function($) {
              
                $('input[name="<?php echo VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE; ?>_<?php echo $index; ?>"]').on("click", function() {
                    $(document.body).trigger("update_checkout");
                    
                });
                
            });*/
            (function($){
            $( 'form.checkout' ).on( 'change', 'input[name="<?php echo VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE; ?>_<?php echo $index; ?>"]', function() {
                $('body').trigger('update_checkout');
                console.log('cambio de paqueteria')
            });
        })(jQuery);
        </script>
    </td>
</tr>
