<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
?>
<div class="recordset">
    <label for="reason_holiday"><?php echo __('Motivo', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></label>
    <input type="text" name="<?php echo VexSolucionesSheduleHoliday::REASON; ?>[]" class="<?php echo VexSolucionesSheduleHoliday::REASON; ?>" value="<?php echo isset($holiday) ? $holiday->reason : ""; ?>">
    <label for="<?php echo VexSolucionesSheduleHoliday::DATE; ?>"><?php echo __('Fecha', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></label>
    <input type="text" name="<?php echo VexSolucionesSheduleHoliday::DATE; ?>[]" class="<?php echo VexSolucionesSheduleHoliday::DATE; ?>" value="<?php echo isset($holiday) ? $holiday->getTraslatedDateTime() : ""; ?>" readonly>
</div>