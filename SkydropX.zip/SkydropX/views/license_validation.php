<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */ 
?>
<h1 class="wc-settings-sub-title " id="woocommerce_skydropx_apiTitle"><?php echo __("Licencia Skydropx Courier API.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h1>
    <p><?php echo __("Configuracion de la api.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></p>
    <table class="form-table">
        <tbody>
            <tr>
                <th scope="row"><label><?php echo __( 'Licencia:', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
                <td>
                <form id="licencia" method="POST" action="<?php echo Vexsoluciones_Woocommerce_Skydropx::plugin_url(). '/includes/license_validation.php'?>">
                    <input name="license" type="text"  class="regular-text" value="<?php echo get_option('skydropx_licensia');?>">
                    <input type="submit" value='Validar' class="button-primary"><br>
                   
					<div id="respuesta"></div>
                    <img id="loading" src="<?php echo Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/images/loader.gif'?>"style="display:none; width:60px;">
</form>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script type="text/javascript">
    (function($){
  $('#licencia').submit(function() {

  jQuery(document).ajaxStart(function () {
            jQuery('#loading').show();
        });
        jQuery(document).ajaxStop(function () {
            jQuery('#loading').hide();
        });

  // Enviamos el formulario usando AJAX

        $.ajax({


            type: 'POST',

            url: $(this).attr('action'),

            data: $(this).serialize(),

            // Mostramos un mensaje con la respuesta de PHP

            success: function(data) {

                $('#respuesta').html(data);
                console.log(data);

            }

        })        

        return false;

    }); 
    })(jQuery);
</script>

                </td>
            </tr>
        </tbody>
    </table>