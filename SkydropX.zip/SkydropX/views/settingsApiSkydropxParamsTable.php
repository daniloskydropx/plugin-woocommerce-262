<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/shop/peru/woocommerce/plugin-woocommerce-skydropx/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
defined( 'ABSPATH' ) || exit;
if(is_admin()): ?>
<style>
    #mainform .avisoskydropxerror:nth-child(3), #mainform #message
    {
        display:none !important;
    }
</style>
    <hr>
    <h1 class="wc-settings-sub-title " id="woocommerce_skydropx_apiTitle"><?php echo __("Skydropx API.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h1>
    <p><?php echo __("Configuracion de la api.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></p>
    <table class="form-table">
        <tbody>
            <tr style="display:none;">
                <th scope="row"><label for="<?php echo VexSolucionesSkydropxSettings::SANDBOX_MODE; ?>"><?php echo __( 'Modo de pruebas', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
                <td>
                    <label>
                    Habilitar
                        <input name="<?php echo VexSolucionesSkydropxSettings::SANDBOX_MODE; ?>" type="radio" id="<?php echo VexSolucionesSkydropxSettings::SANDBOX_MODE; ?>" class="regular-text" value="1" <?= $this->getEnvironmentMode() === 'enabled' ? 'checked' : '' ?>>
                        
                    </label>
                    <label>
                    Deshabilitar
                        <input name="<?php echo VexSolucionesSkydropxSettings::SANDBOX_MODE; ?>" type="radio" id="<?php echo VexSolucionesSkydropxSettings::SANDBOX_MODE; ?>" class="regular-text" value="0" <?= $this->getEnvironmentMode() === 'disabled' ? 'checked' : '' ?>>
                        
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="<?php echo VexSolucionesSkydropxSettings::API_KEY; ?>"><?php echo __( 'API Key', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
                <td>
                    <input name="<?php echo VexSolucionesSkydropxSettings::API_KEY; ?>" type="text" id="<?php echo VexSolucionesSkydropxSettings::API_KEY; ?>" class="regular-text" value="<?php echo $this->getSkydropxApiKey(); ?>">
                    <input type="hidden" name="<?php echo VexSolucionesSkydropxSettings::SHOPID; ?>" id="<?php echo VexSolucionesSkydropxSettings::SHOPID; ?>" value="<?php if(get_option('skydropx_shopid')==false){ echo mt_rand(1111,9999);} else { echo $this->getshopid();}?>">
                </td>


            </tr>
            <?php if(get_option('skydropx_shopid'))
            {
                ?>
            <tr>
            <th scope="row"><label for="<?php echo VexSolucionesSkydropxSettings::API_KEY; ?>"><?php echo __( 'Shop Id', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <label>
                    <?php echo $this->getshopid();?>
                </label>
            </td>
            </tr>
<?php
            }
            ?>
        </tbody>
    </table>
<div style="display:none">
     <table class="form-table test">
     <hr>
        <tbody>
            
            <h1>Google API key</h1>
           <br>
           <tr>
            <th scope="row"><label for="isFlatPriceEnabled"><?php echo __( 'Servicios de Google Maps'); ?></label></th>
                <td>
                    Activados <input class="coupon_question" name="<?php echo VexSolucionesSkydropxSettings::SERVICIOSGOO; ?>" type="radio" id="<?php echo VexSolucionesSkydropxSettings::SERVICIOSGOO; ?>" class="regular-text" value="1" <?= $this->servicesGoogle() === 'enabled' ? 'checked' : '' ?> >

                    Desactivados <input class="close" name="<?php echo VexSolucionesSkydropxSettings::SERVICIOSGOO; ?>" type="radio" id="<?php echo VexSolucionesSkydropxSettings::SERVICIOSGOO; ?>" class="regular-text" value="0" <?= $this->servicesGoogle() === 'disabled' ? 'checked' : '' ?> >
                </td>
</tr>
                  <tr class="answer">
    

                <th scope="row"><label for="<?php echo VexSolucionesSkydropxSettings::GOOGLE_API_KEY; ?>"><?php echo __( 'Google Maps API Key', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
                <td>
                    <input name="<?php echo VexSolucionesSkydropxSettings::GOOGLE_API_KEY; ?>" type="text" id="<?php echo VexSolucionesSkydropxSettings::GOOGLE_API_KEY; ?>" class="regular-text" value="<?php echo $this->getApiKeyGoogle(); ?>">
                </td>
                  <p> Es necesario para las coordenadas y obtener direcciones. Debe crear una cuenta en la consola de google aqui:<a href="https://console.cloud.google.com" target="_blank">https://console.cloud.google.com</a><br>
Como obtener la API Key: <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">https://developers.google.com/maps/documentation/javascript/get-api-key</a><br>
Las siguientes APIS deben estar activadas:
  </p>
   <ul>
        <li>Places API</li>
        <li>Directions API</li>
        <li>Geocoding API</li>
        <li>Maps Javascript API</li>
    </ul>
            </tr>
        </tbody>
    </table>
        </div>
    <?php if($this->servicesGoogle()=='disabled')
    {
        ?>
        <script>
            (function($){
    $(document).ready(function(){
        $(".answer").hide();
    });

})(jQuery);
        </script>
        <?php
    }
    ?>
    <script>
            (function($){
    $(document).ready(function(){
      
$(".coupon_question").click(function() {
    if($(this).is(":checked")) {
        $(".answer").show(300);
    } 
});
$(".close").click(function() {
    if($(this).is(":checked")) {
        $(".answer").hide(300);
    } 
});
});

})(jQuery);
    </script>
<?php
endif;




