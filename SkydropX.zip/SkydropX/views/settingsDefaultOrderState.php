<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
defined( 'ABSPATH' ) || exit;
if(is_admin()): ?>
    <h1 class="wc-settings-sub-title " id="woocommerce_skydropx_statusConfigTitle"><?php echo __("Configuración del estado de la orden.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h1><br>
    <p><?php echo __("Configure cuando debe crearse el pedido de skydropx en conjunto con su logistica<br>Por defecto el skydropx se pide cuando el pedido pasa a estado <b>Completado</b>. Si desea cambiar el estado en que se pedira el skydropx, seleccione el estado en la opcion Estado para generar skydropx.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></p>                
    <table class="form-table">
        <tbody>
            <tr>
                <th scope="row"><label for="<?php echo VexSolucionesSkydropxSettings::ORDER_STATE; ?>"><?php echo __( 'Configuración de estado del pedido', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
                <td>
                    <select name="<?php echo VexSolucionesSkydropxSettings::ORDER_STATE; ?>" id="<?php echo VexSolucionesSkydropxSettings::ORDER_STATE; ?>">
                        <?php
                        $statuses = wc_get_order_statuses();
                        foreach($statuses as $status => $frontendName): ?>
                            <option value="<?php echo $status; ?>" <?php echo $this->getWoocommerceDefaultStatus() == $status ? "selected" : ""; ?>><?php echo $frontendName; ?></option>
                        <?php
                        endforeach; ?>
                    </select>
                    <p><?php echo __("Seleccione el estado para generar el pedido a skydropx.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></p>
                </td>
            </tr>
        </tbody>
    </table>
<?php
endif;