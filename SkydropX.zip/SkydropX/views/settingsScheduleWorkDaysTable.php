<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
defined( 'ABSPATH' ) || exit; ?>
<div style="display:none;">
<hr>
<h1 class="wc-settings-sub-title" style="width: 100%; text-align: left;"><?php echo __( 'Horario de atención.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></h1>
<p><?php echo "Programar los horarios que se permitiran la recolección de pedidos."; ?></p>
<table class="form-table skydropx-form-table skydropx-shedules">
    <tbody>
        <?php
        $i = 0;
        foreach(VexSolucionesDateTimeShedule::getFieldsNames() as $field):
            $i++; $value = VexSolucionesDateTimeShedule::getValueForFieldKey($this->getTimesShedules(), $field);
            if($i == 0): ?> 
            <tr>
            <?php
            endif; ?>
                <?php
                $sinceUntil = __( 'Hasta:', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN );
                if(strpos($field, "Since")): 
                    $sinceUntil = __( 'Desde:', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?>
                <td class="row-label"><label><?php echo VexSolucionesDateTimeShedule::getFieldName($field); ?></label></td>
                <?php
                endif; ?>
                <td>
                    <label for="<?php echo $field; ?>"><?php echo $sinceUntil; ?></label>
                    <input name="<?php echo $field; ?>" type="text" id="<?php echo $field; ?>" class="time-text" value="<?php echo $value; ?>">
                </td>
                <?php
                if(strpos($field, "Until")): 
                    $checkName = str_replace(["Since", "Until"], "", $field); ?>
                    <td class="laborableDay">
                        <label>
                            <input type="checkbox" name="<?php echo "{$checkName}LaborableDay"; ?>" <?php echo empty($value) ? "checked" : "checked"; ?>>
                            <span><?php echo __("Dia Laborable", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></span>
                           
                        </label>
                    </td>
                <?php
                endif;
            if(($i % 2) == 0): ?>
            </tr>
            <?php
            $i = 0;
            endif;
        endforeach; ?>
    </tbody>
</table>
    </div>